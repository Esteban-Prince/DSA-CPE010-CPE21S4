#include <iostream>
#include <stack>
#include <queue>
using namespace std;

  void display(queue<string>pl){
    while(!pl.empty()){
      cout<<pl.front()<<endl;
      pl.pop();
    }
  }

  void empty(queue<string>pl){
    while(true){
      pl.pop();
    }
  }


int main(){
  queue<string>pl;
  cout<<"Push elements into stack"<<endl;

  pl.push("C++");
  pl.push("Python");
  pl.push("Java");
  display(pl);
  cout<<endl;

  cout<<"After popping"<<endl;
  empty(pl);
  
  return 0;
}